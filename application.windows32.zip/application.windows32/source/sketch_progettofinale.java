import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class sketch_progettofinale extends PApplet {

public void setup(){

frameRate(10);
b1=new button2(350,520,300,150,"SCRITTURA IMMEDIATA");
b2=new button2(350,310,300,150,"SCRITTURA DIFFERITA");
b3=new button2(350,100,300,150,"BUS SNOOPING");
core1=new button(260,100,100,100,"CPU1");
core2=new button(620,100,100,100,"CPU2");
core3=new button(300,100,100,100,"CPU1");
core4=new button(600,100,100,100,"CPU2");
cache1=new container(210,250,200,150);
cache11=new container(570,250,200,150);
cache2=new container(240,250,200,150);
cache22=new container(550,250,200,150);
mem=new container(200,450,600,200);
mem2=new container(100,450,800,200);
i1=new copia(220,300,80.0f,50.0f,"C1");
i2=new copia(320,300,80,50,"C2");
i3=new copia(580,300,80,50,"C1");
i7=new copia(680,300,80,50,"C2");
i4=new copia2(260,300,80.0f,50.0f,"C1");
i5=new copia2(350,300,80,50,"C2");
i6=new copia2(570,300,80,50,"C1");
i8=new copia2(660,300,80,50,"C2");
m1=new ind((mem.getX()/2)+200,(mem.getY())+70,80,50,"I1");
m2=new ind((mem.getX()/2)+500,(mem.getY())+70,80,50,"I2");

m4=new ind((mem2.getX()/2)+250,(mem2.getY())+70,80,50,"I1");
m5=new ind((mem2.getX()/2)+550,(mem2.getY())+70,80,50,"I2");

lru=new lru(800,280,100,100);back=new button2(20,20,50,50,"X");
p1=new core (200,50,150,150,"P1");
p2=new core(600,50,150,150,"P2");
cache3=new memoria(180,250,200,150);
cache4=new memoria(580,250,200,150);
ram=new memoria(180,500,600,180);
in1=new indirizzi((cache3.getX() )+40, (cache3.getY())+50,50,50,"I1");
in2=new indirizzi((cache3.getX() )+120, (cache3.getY())+50,50,50,"I2");
in3=new indirizzi((cache4.getX() )+40, (cache4.getY())+50,50,50,"I1");
in4=new indirizzi((cache4.getX() )+120, (cache4.getY())+50,50,50,"I2");
inmem1=new inm((ram.getX())+150,(ram.getY())+80,80,80,"I1");
inmem2=new inm((ram.getX())+350,(ram.getY())+80,80,80,"I2");
read1=new oper(120,60,50,50,"R");
read2=new oper(520,60,50,50,"R");
write1=new oper(380,60,50,50,"W");
write2=new oper(780,60,50,50,"W");
bit1=new bit((inmem1.getX())+100,inmem1.getY(),30,30);
bit2=new bit((inmem2.getX())+100,inmem2.getY(),30,30);
livello=0;


}

button core1,core2,core3,core4;copia i1,i2,i3,i7;copia2 i4,i5,i6,i8;ind m1,m2,m4,m5;
container cache1,cache11,cache22,cache2,mem2,mem;bit bit1,bit2;
button2 b1,b2,b3,back;lru lru;core p1,p2;memoria cache3,cache4,ram;indirizzi in1,in2,in3,in4;inm inmem1,inmem2;oper read1,read2,write1,write2;
int state,state2,livello,col;
int count;int pos;
public void draw(){
 

 
    switch (livello){
      case 0:
       background (0xff6dff4c);
 b1.SetColor(0xff04f238);
 b2.SetColor(0xffefec32);
 b3.SetColor(0xffd142f4);
 b1.display();
 b2.display();
 b3.display();
if(livello==0){
 if(b1.nowPressed()){
 livello=1;}
 else if(b2.nowPressed()){
    livello=2;}
  else if(b3.nowPressed()){
    livello=3;}
}
 break;
      
      case 1:
   background(0xffa7c7d1);
   core1.SetColor(0xff2871e0);core2.SetColor(0xff9b4aad);
   core1.display();
   core2.display();
   cache1.display();cache11.display();
   mem.display();back.display();
   i1.display();i2.display();i3.display();i7.display();
   if(core1.Pressed()==true){
     core2.SetPressed(false);
     state=core1.getColor();}
     else if(core2.Pressed()==true){
       core1.SetPressed(false);
       state=core2.getColor();}
   if(i1.Clicked()){
     i1.update();
     m1.Setc(i1.getColor());i3.SetColor(i1.getColor());
     }
   if(i2.Clicked()){
     i2.update();
   m2.Setc(i2.getColor());i7.SetColor(i2.getColor());}
   if(i3.Clicked()){
       i3.update();
     m1.Setc(i3.getColor());i1.SetColor(i3.getColor());}
     if(i7.Clicked()){
       i7.update();
       i2.SetColor(i7.getColor());m2.Setc(i7.getColor());}
       
   m1.display();m2.display();
   if(back.nowPressed()){livello=0;}
   break;

 
 
 case 2:
   
 background(0xffE6DEEC);
 
 core3.SetColor(0xff2871e0);core4.SetColor(0xff9b4aad);
 lru.display();back.display();
 core3.display();
   core4.display();
   cache2.display();cache22.display();
   mem2.display();
   i4.display();i5.display();i6.display();i8.display();
   m4.display();m5.display();
   if(core3.Pressed()==true){
     core4.SetPressed(false);
     state2=core3.getColor();}
    else if(core4.Pressed()==true){
       core3.SetPressed(false);
       state2=core4.getColor();}
   if(core3.Pressed()){
       if(i4.Clicked()){
         count++;pos++;
         i4.update();i6.Setuso(count);
         i6.SetColor(0xffe1dced);
        }
       if(i5.Clicked()){
         count++;pos++;          
         i5.update();i8.Setuso(count);
         i8.SetColor(0xffe1dced);}}
    else if (core4.Pressed()){
       if(i6.Clicked()){
         count++;pos++;
         i6.update();i4.Setuso(count);
         i4.SetColor(0xffe1dced);}
     if(i8.Clicked()){
         count++;pos++;
         i8.update();i5.Setuso(count);
         i5.SetColor(0xffe1dced);}
    }
   if(lru.Pressed()){
    copia2 min1=isMin(i4,i5);
    copia2 min2=isMin(i6,i8);    
    if (min1.getUso()<min2.getUso()){
      if(min1==i4){
        m4.Setc(i4.getColor());i4.SetColor(0xffffffff);i4.Setuso(pos);}
      else{
         m5.Setc(i5.getColor());
         i5.SetColor(0xffffffff);i5.Setuso(pos);}
    }
        else{
         if(min2==i6){
           m4.Setc(i6.getColor());
           i6.SetColor(0xffffffff);i6.Setuso(pos);}
          else{
            m5.Setc(i8.getColor());
            i8.SetColor(0xffffffff);i8.Setuso(pos);}
     }
   }
   if(back.nowPressed()){livello=0;}
   break;
     
   case 3:
   background(0xffb29cb7);
  p1.SetCol(0xff7513dd);p2.SetCol(0xffd8110a);
  p1.display();p2.display();cache3.display();cache4.display();
  ram.display();in1.display();in2.display();in3.display();in4.display();
  inmem1.display();inmem2.display();bit1.display();bit2.display();
  write1.display();write2.display();read1.display();read2.display();back.display();
  textSize(16);fill(0);
  text("BUS",100,450);
  strokeWeight(10);
  stroke(0);
  line(170,450,800,450);
 if (read1.isPressed()){
   read2.SetPressed(false);write1.SetPressed(false);write2.SetPressed(false);}
 else if(read2.isPressed()){
     read1.SetPressed(false);
     write1.SetPressed(false);write2.SetPressed(false);}
 else if (write1.isPressed()){
     write2.SetPressed(false);
     read1.SetPressed(false);read2.SetPressed(false);}
 else if(write2.isPressed()){
   write1.SetPressed(false);
   read1.SetPressed(false);read2.SetPressed(false);}
   
   if(read1.isPressed() && p1.Pressed()){
     if (inmem1.nowPressed()){
       in1.activate();
     if(bit1.valid()==false){bit1.revalid();}}
     if(inmem2.nowPressed()){
       in2.activate();
     if(bit2.valid()==false){bit2.revalid();}}
   }
   else if(read2.isPressed() && p2.Pressed()){
     if(inmem1.nowPressed()){
       in3.activate();
     if(bit1.valid()==false){bit1.revalid();}}
       if(inmem2.nowPressed()){
       if(bit2.valid()==false){bit2.revalid();}  
       in4.activate();}
   }
   
   if(write1.isPressed() && p1.Pressed()){
     if(inmem1.nowPressed()){
       bit1.update();
       in3.invalidate();
       in1.activate();
     }
     if(inmem2.nowPressed()){
       bit2.update();in4.invalidate();
       in2.activate();}
   }
   else if(write2.isPressed() && p2.Pressed()){
     if(inmem1.nowPressed()){
       bit1.update();in1.invalidate();in3.activate();}
       if(inmem2.nowPressed()){
         bit2.update();in2.invalidate();in4.activate();}
   }
   if(back.nowPressed()){livello=0;}
   break;
       
}
}
public copia2 isMin(copia2 left, copia2 right){
  if (left.getUso() < right.getUso())return left;
  else{return right;}
}
class button{
int activeColor;
float posX,posY,H,L;
Boolean pressed;
String txt;
button(float x,float y,float l,float h,String tx){
  posX=x;posY=y;H=h;L=l;pressed=false;txt=tx;
}
public void SetColor(int c){
  activeColor=c;
}
public void SetPressed(Boolean c){pressed=c;}
public int getColor(){return activeColor;}
public Boolean Pressed(){return pressed;}
public void display(){

if ((mouseX<posX+L && mouseX>posX)&&(mouseY >posY && mouseY < posY+H)){
strokeWeight(4);
stroke(0xfff48342);
}
else{
  strokeWeight(2);
  stroke(0);
}

if(mousePressed){
  if ((mouseX<posX+L && mouseX>posX)&&(mouseY >posY && mouseY < posY+H)){
    if(pressed==false){
      pressed=true;
      fill(activeColor);
    }
    else if(pressed==true){
      pressed=false;
      fill(0xffe1dced);
     }
  }

else{
  if(pressed==false){
    fill(0xffe1dced);
  }
  else{
    fill(activeColor);
  }
}
}
else {
  if(this.pressed==true){
    fill(activeColor);
  }
  else{
    fill(0xffe1dced);
  }  
}

   
rect(posX,posY,L,H);
fill(0);
text(txt,posX+(L/2),posY+(H/2));
}
}

//---------------------------------


class button2{
int activeColor;
float posX,posY,H,L;
Boolean pressed;
String txt;

button2(float x,float y,float l,float h,String tx){
  posX=x;posY=y;H=h;L=l;pressed=false;txt=tx;
}
 public Boolean nowPressed(){ 
          if (mousePressed){
          if (mouseX < (posX+L) && mouseX > posX && mouseY< (posY+H) && mouseY> posY){
            return true;}
            else {return false;}
          }
          return false;
  }
public Boolean Ispressed(){
 return pressed;
  
  }


public void SetColor(int c){
  activeColor=c;
}

public void display(){

if ((mouseX<posX+L && mouseX>posX)&&(mouseY >posY && mouseY < posY+H)){
strokeWeight(7);
stroke(0xfff48342);
}
else{
  strokeWeight(5);
  stroke(0);
}

if(mousePressed){
  if ((mouseX<posX+L && mouseX>posX)&&(mouseY >posY && mouseY < posY+H)){
      pressed=true;
      fill(activeColor);
      
    }
   else{fill(0xffffd88c);}
  }
  else{fill(0xffffd88c);}


  



   
rect(posX,posY,L,H);
textAlign(CENTER);
textSize(20);
fill(0);
text(txt,posX+(L/2),posY+(H/2));
}
}
class container{
  float posX,posY,l,h;
  container(float x,float y,float L,float A){
    posX=x;posY=y;l=L;h=A;
  }
  public void display(){
    strokeWeight(4);
    stroke(0xff33017a);
    fill(0xffdad0e8);
    rect(posX,posY,l,h);
  }
  public float getX(){return posX;}
  public float getY(){return posY;}
}

class memoria{
  
  float posX,posY,L,H;
  memoria(float x,float y,float l,float h){
    posX=x;posY=y;L=l;H=h;}
    public float getX(){return posX;}
    public float getY(){return posY;}
    public void display(){
      strokeWeight(5);stroke(0xff0f0d0d);
      fill(0xfff9d7c7);
      rect(posX,posY,L,H);
    }
}
class bit{
  
  float posX,posY,L,H;String V;Boolean valid;
  bit(float x,float y,float l,float h){
    posX=x;posY=y;L=l;H=h;V="V";valid=true;}
    public float getX(){return posX;}
    public float getY(){return posY;}
    public void update(){ fill(0);
         V="X";valid=false;}
     public Boolean valid(){return valid;}
     public void revalid(){
       V="V";valid=true;}
        
    public void display(){
      strokeWeight(5);stroke(0xff0f0d0d);
      fill(0xfff9d7c7);
      rect(posX,posY,L,H);
      fill(0);
      textSize(15);
      text(V,posX+10,posY+20);
      
}
}
class copia{
int activeColor;
float posX,posY,H,L;
Boolean pressed;
String txt;
copia(float x,float y,float l,float h,String tx){
  posX=x;posY=y;H=h;L=l;pressed=false;txt=tx;activeColor=0xffe1dced;
}
public void SetColor(int c){
  activeColor=c;
}
public int getColor(){return activeColor;}
public void SetPressed(Boolean t){pressed=t;}
public void update(){
  activeColor=state;}
public Boolean Clicked(){
  if(mousePressed){
  if ((mouseX<posX+L && mouseX>posX)&&(mouseY >posY && mouseY < posY+H)){
    return true;}
    else{ return false;}
}
else{return false;}
}
public Boolean Pressed(){return pressed;}
public void display(){

if ((mouseX<posX+L && mouseX>posX)&&(mouseY >posY && mouseY < posY+H)){
strokeWeight(4);
stroke(0xfff48342);
}
else{
  strokeWeight(2);
  stroke(0);
}

fill(activeColor);
   
rect(posX,posY,L,H);
fill(0);
textSize(16);
text(txt,posX+(L/2),posY+(H/2));
}
}
//--------------------------------
class copia2{
int activeColor,uso;
float posX,posY,H,L;
Boolean pressed;
String txt;
copia2(float x,float y,float l,float h,String tx){
  posX=x;posY=y;H=h;L=l;pressed=false;txt=tx;activeColor=0xffe1dced;uso=0;
}
public void SetColor(int c){
  activeColor=c;
}

public void Setuso(int b){uso=b;}
public int getColor(){return activeColor;}
public void SetPressed(Boolean t){pressed=t;}
public int getUso(){return uso;}
public void update(){
  activeColor=state2;
  uso=count;}
public Boolean Clicked(){
  if(mousePressed){
  if ((mouseX<posX+L && mouseX>posX)&&(mouseY >posY && mouseY < posY+H)){
    return true;}
    else{ return false;}
}
else{return false;}
}
public Boolean Pressed(){return pressed;}
public void display(){

if ((mouseX<posX+L && mouseX>posX)&&(mouseY >posY && mouseY < posY+H)){
strokeWeight(4);
stroke(0xfff48342);
}
else{
  strokeWeight(2);
  stroke(0);
}

fill(activeColor);
   
rect(posX,posY,L,H);
fill(0);
textSize( 16);
text(txt,posX+(L/2),posY+(H/2));
}
}
class core{
  float posX,posY,L,H;String p;Boolean pressed;int Active;
  core(float x,float y,float l,float h,String n){
    posX=x;posY=y;L=l;H=h;p=n;pressed=false;}
    public int getColor(){return Active;}
    public void SetCol(int c){Active=c;}
    public Boolean Pressed(){return pressed;}
    public void display(){
 if (mouseX >posX && mouseX<(posX+L)&& mouseY>posY && mouseY<(posY+H)){
   strokeWeight(5);
   
    }
    else {
      strokeWeight(2);
    }
    if(mousePressed){
      if(mouseX >posX && mouseX<(posX+L)&& mouseY>posY && mouseY<(posY+H)){
        if(pressed==false){
            pressed=true;
            fill(Active);}
         else{pressed=false;
       fill(0xffffffff);}
      }
      else {
      if(pressed==false){
      fill(0xffffffff);}
      else if(pressed){
        fill(Active);
        }
      }
    }
    else {
      if(pressed==false){
      fill(0xffffffff);}
      else if(pressed){
        fill(Active);
        }
    }
      
    stroke(0xff0f0d0d);
    
    rect(posX,posY,L,H);
    fill(0xff0f0d0d);textSize(20);
    text(p,posX+(L/2)-10,posY+(H/2));
    
}
}
class ind{
  float posX,posY,L,H;String t;
  int colore;
  ind(float x,float y,float l,float h,String tx){
    posX=x;posY=y;L=l;H=h;colore=0xffe1dced;t=tx;}
    public void Setc(int c){colore=c;}
    
    public void display(){
      fill(colore);
      strokeWeight(2);
      stroke(0);
      rect(posX,posY,L,H);
      fill(0);
      text(t,posX+(L/2),posY+(H/2));
    }
}
//-----------------------------------------------------------------------
class inm{
  float posX,posY,L,H;String t;
  Boolean pressed;
  int colore;
  inm(float x,float y,float l,float h,String p){
    posX=x;posY=y;L=l;H=h;t=p;pressed=false;colore=0xffc7e7f9;}
    public float getX(){return posX;}
    public float getY(){return posY;}
    public Boolean Pressed(){return pressed;}
    public Boolean nowPressed(){ 
          if (mousePressed){
          if (mouseX < (posX+L) && mouseX > posX && mouseY< (posY+H) && mouseY> posY){
            return true;}
            else {return false;}
          }
          return false;
  }
     public void display(){
       if (mouseX>posX && mouseX < (posX+L) && mouseY>posY && mouseY< (posY+H)){
         strokeWeight(4);
       }
       else {strokeWeight(2);}
       if(mousePressed){
         if(mouseX >posX && mouseX<(posX+L) && mouseY>posY && mouseY<(posY+H)){
           pressed=true;}
       }
       
         stroke(0xff01031e);
         fill(colore);
         rect(posX,posY,L,H);
         fill(0xff0f0d0d);
          textSize(10);
          text(t,posX+(L/2),posY+(H/2));
     }
}
//------------------------------------------------------------------------------
class indirizzi{
  float posX,posY,H,L;String tx;Boolean pressed,modified,active;
  public void invalidate(){active=false;}
  public Boolean isPressed(){return pressed;}
  
  public Boolean nowPressed(){ 
          if (mousePressed){
          if (mouseX < (posX+L) && mouseX > posX && mouseY< (posY+H) && mouseY> posY){
            return true;}
            else {return false;}
          }
          return false;
  }
  
    
  indirizzi(float x,float y,float l,float h,String p){
    posX=x;posY=y;L=l;H=h;pressed=false;modified=false;active=false;tx=p;}
    public void activate(){
      if (active==false){active=true;}
    }
     public void display(){
       if (mouseX>posX && mouseX < (posX+L) && mouseY>posY && mouseY< (posY+H)){
         strokeWeight(4);
       }
       else {strokeWeight(2);}
       if(active==false){
       stroke(0xffc6bdb8);
       fill(0xffccccce);}
       else{
         stroke(0xff01031e);
         fill(0xffc7e7f9);
       }
       rect(posX,posY,L,H);
       if(active){
         fill(0xff0f0d0d);
       }
       else{ fill(0xff929393);}
      textSize(10);
      text(tx,posX+(L/2),posY+(H/2));
     }
}
class lru{
float posX,posY,L,H;
lru(float x,float y,float l,float h){
  
  posX=x;posY=y;L=l;H=h;}
  public Boolean Pressed(){
    if(mousePressed){
  if ((mouseX<posX+L && mouseX>posX)&&(mouseY >posY && mouseY < posY+H)){
    return true;}
    else {return false;}
    }
    else {return false;}
  }
    
    public void display(){
      
      if ((mouseX<posX+L && mouseX>posX)&&(mouseY >posY && mouseY < posY+H)){
        stroke(0xffF21A1A);
        strokeWeight(3);}
        else{
          stroke(0);
      strokeWeight(1);}
        fill(0xffF7EEDF);
        rect(posX,posY,L,H);
       
        fill(0xffA20B1A);
        text("LRU",posX+(L/2),posY+(H/2));
    }


}
class oper{
  float X,Y,L,H;String T;Boolean pressed;
  oper(float x,float y,float l,float h,String t){
    X=x;Y=y;L=l;T=t;H=h;pressed=false;}
    public Boolean isPressed(){ return pressed;}
    public void SetPressed(Boolean x){pressed=x;}
    public void display(){
      if (mouseX < (X+L) && mouseX > X && mouseY< (Y+H) && mouseY> Y){
        strokeWeight(4);stroke(0xff0a0a0a);}
        else{
          if(pressed==true){
          strokeWeight(3);stroke(0xffff0000);}
         else{
           strokeWeight(2);stroke(0xff2b2b2b);}
        }
        
        if (mousePressed){
          if (mouseX < X+L && mouseX > X && mouseY< Y+H && mouseY> Y){
            if(pressed==false){pressed=true;stroke(0xffff0000);}
            else {pressed=false;stroke(0xff0a0a0a);}
          }
        }
       
           fill(0xffffffff);
           rect(X,Y,L,H);
           textSize(20);
           textMode(CENTER);
           fill(0xffff0000);
           text(T,X+(L/2),Y+(H/2)+5);
    }
}
           
    
          
  
  public void settings() { 
size(1000,1000); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "sketch_progettofinale" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
